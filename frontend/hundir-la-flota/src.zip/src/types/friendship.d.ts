// src/types/friendship.d.ts
export type PendingRequest = {
  id: string;
  senderId: string;
  senderNickname: string;
  createdAt: string;
};

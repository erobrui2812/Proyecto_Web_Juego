declare module 'prop-types';
declare module "signalr";
  